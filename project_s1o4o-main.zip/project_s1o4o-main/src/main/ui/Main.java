package ui;



import java.io.FileNotFoundException;


//initializes CalorieTracker
public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        new CalorieTracker();
    }
}
